"""
Script to generate the default placeholder thumbnail.
Run once: python generate_defaults.py
"""
from PIL import Image, ImageDraw, ImageFont
import os

os.makedirs("static/thumbnails", exist_ok=True)

img  = Image.new("RGB", (400, 280), color="#263C85")
draw = ImageDraw.Draw(img)
draw.rectangle([0, 240, 400, 280], fill="#FF6B35")

try:
    font = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf", 28)
    small = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", 16)
except IOError:
    font = small = ImageFont.load_default()

draw.text((20, 100), "Template", fill="white", font=font)
draw.text((20, 140), "Marketplace", fill="white", font=font)
draw.text((20, 247), "Professional Template", fill="white", font=small)

img.save("static/thumbnails/default.png")
print("Default thumbnail created.")
