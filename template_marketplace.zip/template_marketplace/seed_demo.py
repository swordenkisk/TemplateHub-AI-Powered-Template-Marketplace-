"""
seed_demo.py — Populate the store with demo products (no API key needed).
Run: python seed_demo.py
"""
import json
import os
from generator.file_creator import TemplateCreator

creator  = TemplateCreator()
products = []

DEMO_PRODUCTS = [
    {
        "type": "presentation",
        "title": "Startup Pitch Deck",
        "description": "A clean, investor-ready pitch deck with 12 slides covering problem, solution, market, traction, and team.",
        "long_desc": "Designed for early-stage founders, this pitch deck template follows the proven Sequoia Capital structure. Each slide is thoughtfully laid out with placeholder text, charts, and icon suggestions.\n\nThe deck covers all the sections investors expect: problem statement, solution overview, total addressable market, business model, competitive analysis, traction metrics, go-to-market strategy, team bios, financial projections, and your ask.\n\nWith a modern blue-and-orange colour scheme and editable PPTX format, you can customise it in minutes.",
        "audience": "Startup founders",
        "features": ["12 professional slides", "Sequoia structure", "Editable PPTX", "Modern design", "Investor-ready"],
        "price_suggestion": 14.99,
        "slides": [
            {"title": "The Problem", "bullets": ["Businesses waste 4 hours/day on manual reporting", "Existing tools are complex and overpriced", "87% of SMBs lack real-time insights"]},
            {"title": "Our Solution", "bullets": ["One-click automated reporting", "Powered by AI — no setup needed", "Results in 60 seconds or less"]},
            {"title": "Market Opportunity", "bullets": ["$48B global business intelligence market", "Growing at 12% CAGR through 2028", "Targeting 5M+ SMBs in English-speaking markets"]},
            {"title": "Business Model", "bullets": ["SaaS subscription: $29–$199/month", "Annual plans with 20% discount", "Enterprise custom pricing"]},
            {"title": "Traction", "bullets": ["1,200 paying customers in 6 months", "$52K MRR growing 18% month-over-month", "Net Promoter Score of 72"]},
            {"title": "Go-To-Market", "bullets": ["SEO + content marketing (primary)", "Product-led growth + viral loops", "Strategic partnerships with accountants"]},
            {"title": "Competitive Landscape", "bullets": ["10x cheaper than Tableau", "3x faster setup than Power BI", "AI-native vs. legacy tools"]},
            {"title": "Team", "bullets": ["Jane Doe, CEO — ex-Salesforce, 10 yrs SaaS", "John Smith, CTO — ex-Google, ML expert", "3 engineers + 1 designer"]},
            {"title": "Financials", "bullets": ["$120K ARR today", "Path to $1M ARR in 12 months", "18-month runway with current raise"]},
            {"title": "The Ask", "bullets": ["Raising $750K pre-seed", "18 months of runway", "Use of funds: 60% eng, 30% growth, 10% ops"]},
        ],
    },
    {
        "type": "spreadsheet",
        "title": "Monthly Budget Tracker",
        "description": "A comprehensive personal or business monthly budget tracker with income, expenses, and savings goals.",
        "long_desc": "Take full control of your finances with this colour-coded budget tracker. Track income sources, categorise all expenses, and automatically see your monthly surplus or deficit.\n\nBuilt with clean formulas for running totals, percentage breakdowns, and savings-rate calculation. Twelve pre-built monthly tabs plus a yearly summary dashboard included.",
        "audience": "Individuals and small businesses",
        "features": ["12 monthly sheets", "Auto-totals & formulas", "Expense categories", "Savings goal tracker", "Charts ready"],
        "price_suggestion": 7.99,
        "data": {
            "headers": ["Category", "Jan Budget", "Jan Actual", "Feb Budget", "Feb Actual", "Notes"],
            "rows": [
                ["Rent / Mortgage", 1500, 1500, 1500, 1500, "Fixed"],
                ["Groceries",        400,  380,  400,  420, "Varies"],
                ["Transport",        150,  135,  150,  160, "Bus + Uber"],
                ["Utilities",        120,  115,  120,  130, "Electricity, Water"],
                ["Internet & Phone", 80,    80,   80,   80, "Fixed"],
                ["Entertainment",   100,   95,  100,   75, "Streaming + events"],
                ["Health & Gym",    60,    60,   60,   60, "Fixed"],
                ["Dining Out",      200,  230,  200,  175, "Target: reduce"],
                ["Savings",         300,  300,  300,  350, "Emergency fund"],
                ["Miscellaneous",   100,   88,  100,  112, "Various"],
            ],
        },
    },
    {
        "type": "business_plan",
        "title": "E-Commerce Business Plan",
        "description": "A full business plan template for launching an e-commerce brand — from market analysis to financial projections.",
        "long_desc": "Whether you're pitching to investors or mapping your own roadmap, this 10-section business plan covers everything an e-commerce venture needs.\n\nEach section includes guiding prompts and example text so you know exactly what to fill in. Compatible with all versions of Microsoft Word and Google Docs.",
        "audience": "E-commerce entrepreneurs",
        "features": ["10 structured sections", "Financial projection tables", "Market research framework", "DOCX format", "Investor-ready"],
        "price_suggestion": 12.99,
        "sections": [
            {"heading": "Executive Summary", "text": "Provide a concise overview of your e-commerce business. Include your value proposition, target market, key differentiators, and high-level financial goals. This section is written last but appears first — make it compelling."},
            {"heading": "Company Description", "text": "Describe your company's mission, vision, and core values. Explain what you sell, your brand story, and the problem you solve for customers. Include your legal structure (LLC, sole proprietor, etc.) and founding date."},
            {"heading": "Market Analysis", "text": "Analyse your target market size, growth rate, and key segments. Identify your ideal customer persona with demographics, psychographics, and buying behaviour. Include data sources to substantiate your claims."},
            {"heading": "Competitive Analysis", "text": "List your top 5 competitors and compare them across price, quality, brand, fulfilment speed, and customer experience. Use a table. Clearly articulate your competitive advantage and why customers will choose you."},
            {"heading": "Products & Services", "text": "Describe each product or product category you offer. Include sourcing strategy (private label, wholesale, dropship, or self-made), pricing tiers, and any intellectual property. Highlight bestsellers and upcoming launches."},
            {"heading": "Marketing Strategy", "text": "Detail your customer acquisition channels: paid social, SEO/content, influencer, email, and referral. Include a 12-month content calendar outline. State your target CAC, LTV, and blended ROAS."},
            {"heading": "Operations Plan", "text": "Describe your supply chain, fulfilment model (3PL, self-fulfilment, or dropship), technology stack (Shopify, WooCommerce, etc.), customer service approach, and quality control processes."},
            {"heading": "Management Team", "text": "Introduce key team members with roles and relevant experience. If you are a solo founder, identify planned hires and freelancers. Advisors and mentors can be listed here too."},
            {"heading": "Financial Projections", "text": "Present 3-year revenue forecasts, cost of goods, gross margin, operating expenses, and net profit. Include a break-even analysis and monthly cash-flow table for Year 1. State key assumptions clearly."},
            {"heading": "Funding Request", "text": "If seeking investment, state the amount requested, preferred structure (equity, convertible note, revenue-share), use of funds broken down by category, and expected milestones the capital will unlock."},
        ],
    },
    {
        "type": "canva",
        "title": "Social Media Content Calendar",
        "description": "A beautiful visual content calendar template with 30 days of planned posts, themes, and copy guidelines.",
        "long_desc": "Stop scrambling for content ideas. This Social Media Content Calendar gives you a structured month-by-month framework for Instagram, LinkedIn, TikTok, and Twitter.\n\nIncludes 30-day grid, content pillars, caption formulas, hashtag strategy, and engagement boosting tips — all laid out in an easy-to-follow PDF you can adapt in Canva.",
        "audience": "Social media managers and creators",
        "features": ["30-day content grid", "4 content pillars", "Caption templates", "Hashtag strategy", "Canva-ready design"],
        "price_suggestion": 9.99,
        "content": """# Social Media Content Calendar Template

## Content Pillars
Define 4 pillars that your brand will consistently post about:
1. Educational / How-to (40% of content)
2. Behind-the-scenes / Brand story (20%)
3. Product / Service highlights (25%)
4. Community / User-generated content (15%)

## Week 1 Plan
Day 1 — Monday: Educational post — "5 tips for [your niche]"
Day 2 — Tuesday: Product highlight with lifestyle photo
Day 3 — Wednesday: Behind-the-scenes Reel
Day 4 — Thursday: Customer testimonial or UGC repost
Day 5 — Friday: Fun / trend-driven content
Day 6 — Saturday: Weekend engagement question
Day 7 — Sunday: Weekly recap or inspiration quote

## Week 2 Plan
Day 8: Deep-dive educational carousel (5–7 slides)
Day 9: New product announcement or teaser
Day 10: Team or founder story
Day 11: FAQ post — answer top customer questions
Day 12: Collab or shoutout post
Day 13: Poll or interactive story
Day 14: Community highlight or milestone celebration

## Caption Formula
Hook (first line grabs attention)
→ Value / Story (2–4 sentences)
→ CTA (ask a question or give a direction)
→ Hashtags (mix of niche, medium, and broad — 10–15)

## Hashtag Strategy
- 5 niche hashtags (under 50K posts) — high visibility
- 5 medium hashtags (50K–500K) — steady reach
- 5 broad hashtags (500K+) — discovery

## Engagement Boosters
- Reply to every comment within the first hour
- Use Stories polls 3× per week
- Post at peak times for your audience (check Insights)
- Collaborate with 1–2 creators per month
- Run a monthly giveaway tied to your content pillar
""",
    },
]

for i, demo in enumerate(DEMO_PRODUCTS, 1):
    t = demo["type"]
    safe_name = "".join(c if c.isalnum() else "_" for c in demo["title"])[:40]

    if t == "presentation":
        filepath = creator.create_pptx(demo["title"], demo["slides"], f"{safe_name}.pptx")
    elif t == "spreadsheet":
        filepath = creator.create_xlsx(demo["title"], demo["data"], f"{safe_name}.xlsx")
    elif t == "business_plan":
        filepath = creator.create_docx(demo["title"], demo["sections"], f"{safe_name}.docx")
    elif t == "canva":
        filepath = creator.create_pdf(demo["title"], demo["content"], f"{safe_name}.pdf")
    else:
        continue

    thumbnail = creator.create_thumbnail(demo["title"], t, i)

    products.append({
        "id":          i,
        "title":       demo["title"],
        "description": demo["description"],
        "long_desc":   demo["long_desc"],
        "price":       demo["price_suggestion"],
        "type":        t,
        "file":        filepath,
        "thumbnail":   thumbnail,
        "audience":    demo["audience"],
        "features":    demo["features"],
        "created_at":  "2024-01-15T10:00:00",
    })
    print(f"✅ Created: {demo['title']}")

with open("products.json", "w", encoding="utf-8") as f:
    json.dump(products, f, indent=2, ensure_ascii=False)

print(f"\n🎉 Seeded {len(products)} demo products into products.json")
