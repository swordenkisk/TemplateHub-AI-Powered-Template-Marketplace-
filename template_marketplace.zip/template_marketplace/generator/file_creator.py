import os
from pptx import Presentation
from pptx.util import Inches, Pt, Emu
from pptx.dml.color import RGBColor
from pptx.enum.text import PP_ALIGN
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from docx import Document
from docx.shared import Pt as DocPt, RGBColor as DocRGB, Inches as DocInches
from docx.enum.text import WD_ALIGN_PARAGRAPH
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import letter
from reportlab.lib import colors
from reportlab.lib.units import inch
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from PIL import Image, ImageDraw, ImageFont
import io


class TemplateCreator:
    def __init__(self, output_dir: str = "generated_templates"):
        self.output_dir = output_dir
        os.makedirs(output_dir, exist_ok=True)

    # ─────────────────────────────────────────────
    # PPTX
    # ─────────────────────────────────────────────
    def create_pptx(self, title: str, slides_data: list, filename: str) -> str:
        prs = Presentation()
        prs.slide_width = Inches(13.33)
        prs.slide_height = Inches(7.5)

        # Colour palette
        PRIMARY = RGBColor(0x26, 0x3C, 0x85)   # deep blue
        ACCENT  = RGBColor(0xFF, 0x6B, 0x35)   # orange
        LIGHT   = RGBColor(0xF5, 0xF7, 0xFF)   # near-white
        WHITE   = RGBColor(0xFF, 0xFF, 0xFF)

        def _bg(slide, color):
            bg = slide.background
            fill = bg.fill
            fill.solid()
            fill.fore_color.rgb = color

        # ── Title slide ──────────────────────────
        slide = prs.slides.add_slide(prs.slide_layouts[6])  # blank
        _bg(slide, PRIMARY)
        txBox = slide.shapes.add_textbox(Inches(1), Inches(2.5), Inches(11.33), Inches(1.5))
        tf = txBox.text_frame
        tf.word_wrap = True
        p = tf.paragraphs[0]
        p.alignment = PP_ALIGN.CENTER
        run = p.add_run()
        run.text = title
        run.font.size = Pt(44)
        run.font.bold = True
        run.font.color.rgb = WHITE

        # Subtitle bar
        bar = slide.shapes.add_shape(
            1,  # MSO_SHAPE_TYPE.RECTANGLE
            Inches(3), Inches(4.2), Inches(7.33), Inches(0.08)
        )
        bar.fill.solid()
        bar.fill.fore_color.rgb = ACCENT
        bar.line.fill.background()

        sub_box = slide.shapes.add_textbox(Inches(1), Inches(4.4), Inches(11.33), Inches(0.8))
        tf2 = sub_box.text_frame
        p2 = tf2.paragraphs[0]
        p2.alignment = PP_ALIGN.CENTER
        r2 = p2.add_run()
        r2.text = "Professional Template"
        r2.font.size = Pt(18)
        r2.font.color.rgb = ACCENT

        # ── Content slides ───────────────────────
        for i, slide_info in enumerate(slides_data):
            slide = prs.slides.add_slide(prs.slide_layouts[6])
            _bg(slide, LIGHT if i % 2 == 0 else WHITE)

            # Header strip
            header = slide.shapes.add_shape(
                1, Inches(0), Inches(0), Inches(13.33), Inches(1.1)
            )
            header.fill.solid()
            header.fill.fore_color.rgb = PRIMARY
            header.line.fill.background()

            # Slide number badge
            badge = slide.shapes.add_shape(
                1, Inches(12.0), Inches(0.1), Inches(0.9), Inches(0.9)
            )
            badge.fill.solid()
            badge.fill.fore_color.rgb = ACCENT
            badge.line.fill.background()

            badge_tf = badge.text_frame
            badge_p = badge_tf.paragraphs[0]
            badge_p.alignment = PP_ALIGN.CENTER
            badge_r = badge_p.add_run()
            badge_r.text = str(i + 1)
            badge_r.font.size = Pt(16)
            badge_r.font.bold = True
            badge_r.font.color.rgb = WHITE

            # Title text
            title_box = slide.shapes.add_textbox(
                Inches(0.3), Inches(0.1), Inches(11.5), Inches(0.9)
            )
            title_tf = title_box.text_frame
            title_p = title_tf.paragraphs[0]
            title_r = title_p.add_run()
            title_r.text = slide_info.get("title", "")
            title_r.font.size = Pt(26)
            title_r.font.bold = True
            title_r.font.color.rgb = WHITE

            # Bullet content
            content_box = slide.shapes.add_textbox(
                Inches(0.5), Inches(1.3), Inches(12.33), Inches(5.8)
            )
            content_tf = content_box.text_frame
            content_tf.word_wrap = True

            bullets = slide_info.get("bullets", [])
            for j, bullet in enumerate(bullets):
                if j == 0:
                    bp = content_tf.paragraphs[0]
                else:
                    bp = content_tf.add_paragraph()
                bp.space_before = Pt(6)
                br = bp.add_run()
                br.text = f"▸  {bullet}"
                br.font.size = Pt(17)
                br.font.color.rgb = PRIMARY if j % 2 == 0 else RGBColor(0x44, 0x44, 0x44)

        filepath = os.path.join(self.output_dir, filename)
        prs.save(filepath)
        return filepath

    # ─────────────────────────────────────────────
    # XLSX
    # ─────────────────────────────────────────────
    def create_xlsx(self, title: str, data: dict, filename: str) -> str:
        wb = Workbook()
        ws = wb.active
        ws.title = title[:31]

        # Styles
        header_font   = Font(name="Calibri", bold=True, color="FFFFFF", size=12)
        header_fill   = PatternFill("solid", fgColor="26 3C 85".replace(" ", ""))
        alt_fill      = PatternFill("solid", fgColor="EEF2FF")
        center_align  = Alignment(horizontal="center", vertical="center", wrap_text=True)
        thin_border   = Border(
            left=Side(style="thin", color="CCCCCC"),
            right=Side(style="thin", color="CCCCCC"),
            bottom=Side(style="thin", color="CCCCCC"),
            top=Side(style="thin", color="CCCCCC"),
        )

        headers = data.get("headers", [])
        rows    = data.get("rows", [])

        # Title row
        ws.merge_cells(start_row=1, start_column=1, end_row=1, end_column=max(len(headers), 1))
        title_cell = ws.cell(row=1, column=1, value=title)
        title_cell.font = Font(name="Calibri", bold=True, size=16, color="263C85")
        title_cell.alignment = center_align
        ws.row_dimensions[1].height = 30

        # Header row
        for col, header in enumerate(headers, 1):
            cell = ws.cell(row=2, column=col, value=header)
            cell.font = header_font
            cell.fill = header_fill
            cell.alignment = center_align
            cell.border = thin_border
            ws.column_dimensions[cell.column_letter].width = max(18, len(str(header)) + 4)
        ws.row_dimensions[2].height = 22

        # Data rows
        for r_idx, row in enumerate(rows, 3):
            fill = alt_fill if r_idx % 2 == 0 else None
            for c_idx, value in enumerate(row, 1):
                cell = ws.cell(row=r_idx, column=c_idx, value=value)
                cell.alignment = Alignment(horizontal="left", vertical="center", wrap_text=True)
                cell.border = thin_border
                if fill:
                    cell.fill = fill
            ws.row_dimensions[r_idx].height = 18

        # Freeze header
        ws.freeze_panes = "A3"

        filepath = os.path.join(self.output_dir, filename)
        wb.save(filepath)
        return filepath

    # ─────────────────────────────────────────────
    # DOCX
    # ─────────────────────────────────────────────
    def create_docx(self, title: str, sections: list, filename: str) -> str:
        doc = Document()

        # Page margins
        for section in doc.sections:
            section.left_margin   = DocInches(1.0)
            section.right_margin  = DocInches(1.0)
            section.top_margin    = DocInches(1.0)
            section.bottom_margin = DocInches(1.0)

        # Title
        title_para = doc.add_paragraph()
        title_para.alignment = WD_ALIGN_PARAGRAPH.CENTER
        run = title_para.add_run(title)
        run.font.size = DocPt(28)
        run.font.bold = True
        run.font.color.rgb = DocRGB(0x26, 0x3C, 0x85)

        doc.add_paragraph()  # spacer

        # Sections
        for i, sec in enumerate(sections):
            heading_para = doc.add_paragraph()
            h_run = heading_para.add_run(f"{i+1}. {sec.get('heading', '')}")
            h_run.font.size = DocPt(14)
            h_run.font.bold = True
            h_run.font.color.rgb = DocRGB(0xFF, 0x6B, 0x35)

            body_para = doc.add_paragraph(sec.get("text", ""))
            body_para.paragraph_format.left_indent = DocInches(0.2)
            body_para.paragraph_format.space_after = DocPt(10)

        # Footer note
        footer_para = doc.add_paragraph()
        footer_para.alignment = WD_ALIGN_PARAGRAPH.CENTER
        footer_run = footer_para.add_run("─── Generated by Template Marketplace ───")
        footer_run.font.size = DocPt(9)
        footer_run.font.color.rgb = DocRGB(0xAA, 0xAA, 0xAA)

        filepath = os.path.join(self.output_dir, filename)
        doc.save(filepath)
        return filepath

    # ─────────────────────────────────────────────
    # PDF
    # ─────────────────────────────────────────────
    def create_pdf(self, title: str, content: str, filename: str) -> str:
        filepath = os.path.join(self.output_dir, filename)

        styles = getSampleStyleSheet()
        title_style = ParagraphStyle(
            "CustomTitle",
            parent=styles["Title"],
            fontSize=24,
            textColor=colors.HexColor("#263C85"),
            spaceAfter=20,
        )
        body_style = ParagraphStyle(
            "CustomBody",
            parent=styles["Normal"],
            fontSize=11,
            leading=16,
            spaceAfter=8,
        )
        heading_style = ParagraphStyle(
            "CustomHeading",
            parent=styles["Heading2"],
            fontSize=14,
            textColor=colors.HexColor("#FF6B35"),
            spaceBefore=14,
            spaceAfter=6,
        )

        story = [Paragraph(title, title_style), Spacer(1, 0.2 * inch)]

        lines = content.split("\n")
        for line in lines:
            line = line.strip()
            if not line:
                story.append(Spacer(1, 0.1 * inch))
            elif line.startswith("#"):
                story.append(Paragraph(line.lstrip("#").strip(), heading_style))
            else:
                story.append(Paragraph(line, body_style))

        # Footer
        story.append(Spacer(1, 0.5 * inch))
        story.append(Paragraph(
            "<i>Generated by Template Marketplace</i>",
            ParagraphStyle("Footer", parent=styles["Normal"], fontSize=9,
                           textColor=colors.grey, alignment=1)
        ))

        doc = SimpleDocTemplate(filepath, pagesize=letter,
                                leftMargin=inch, rightMargin=inch,
                                topMargin=inch, bottomMargin=inch)
        doc.build(story)
        return filepath

    # ─────────────────────────────────────────────
    # Thumbnail
    # ─────────────────────────────────────────────
    def create_thumbnail(self, title: str, template_type: str, product_id: int) -> str:
        """Create a simple colourful thumbnail PNG."""
        type_colors = {
            "presentation": ("#263C85", "#FF6B35"),
            "spreadsheet":  ("#1E7E34", "#28A745"),
            "business_plan": ("#6F42C1", "#9B59B6"),
            "canva":         ("#C0392B", "#E74C3C"),
        }
        bg_color, accent = type_colors.get(template_type, ("#263C85", "#FF6B35"))

        img = Image.new("RGB", (400, 280), color=bg_color)
        draw = ImageDraw.Draw(img)

        # Accent bar at bottom
        draw.rectangle([0, 240, 400, 280], fill=accent)

        # Type badge top-right
        draw.rectangle([300, 10, 390, 40], fill=accent)

        # Title text (simple)
        try:
            font_large = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf", 22)
            font_small = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", 14)
            font_badge = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf", 12)
        except IOError:
            font_large = font_small = font_badge = ImageFont.load_default()

        # Wrap title
        words = title.split()
        lines, line = [], []
        for w in words:
            if len(" ".join(line + [w])) <= 22:
                line.append(w)
            else:
                if line:
                    lines.append(" ".join(line))
                line = [w]
        if line:
            lines.append(" ".join(line))

        y = 80
        for l in lines[:4]:
            draw.text((20, y), l, fill="white", font=font_large)
            y += 32

        draw.text((20, 245), f"Template Marketplace", fill="white", font=font_small)
        draw.text((305, 17), template_type[:12].upper(), fill="white", font=font_badge)

        thumb_dir = os.path.join("static", "thumbnails")
        os.makedirs(thumb_dir, exist_ok=True)
        filepath = os.path.join(thumb_dir, f"thumb_{product_id}.png")
        img.save(filepath)
        return f"/static/thumbnails/thumb_{product_id}.png"
