import os
import json
import re
from openai import OpenAI

client = OpenAI(
    api_key=os.getenv("DEEPSEEK_API_KEY"),
    base_url="https://api.deepseek.com/v1"
)


def _extract_json(text: str):
    """Extract JSON from a response that may contain markdown fences."""
    # Strip ```json ... ``` or ``` ... ```
    match = re.search(r"```(?:json)?\s*([\s\S]*?)```", text)
    if match:
        text = match.group(1)
    return json.loads(text.strip())


def generate_template_ideas(template_type: str, count: int = 5) -> list:
    """Generate creative ideas for templates of a given type."""
    prompt = f"""
Generate {count} creative and highly marketable ideas for {template_type} templates 
that professionals and students would be willing to pay for.

Each idea must include:
- title: short catchy name
- description: 1-2 sentences explaining why it's useful
- audience: target buyer (e.g., "Marketing teams", "Freelancers", "Students")
- features: list of 3-5 key selling points
- price_suggestion: suggested price in USD (between 5 and 49)

Return ONLY a valid JSON array of objects with keys: title, description, audience, features, price_suggestion.
No extra text. No markdown fences.
"""
    response = client.chat.completions.create(
        model="deepseek-chat",
        messages=[
            {"role": "system", "content": "You are an expert digital product creator specializing in sellable templates."},
            {"role": "user", "content": prompt}
        ],
        temperature=0.8,
        max_tokens=3000,
    )
    raw = response.choices[0].message.content
    try:
        return _extract_json(raw)
    except Exception:
        return []


def generate_template_content(template_type: str, idea: dict) -> dict:
    """Generate detailed structured content for a template."""
    features_str = ", ".join(idea.get("features", []))
    prompt = f"""
Create detailed content for a {template_type} template:
- Title: {idea['title']}
- Description: {idea['description']}
- Audience: {idea['audience']}
- Features: {features_str}

Rules depending on type:
- "presentation": return "slides" as an array of objects with "title" (string) and "bullets" (array of strings). At least 8 slides.
- "spreadsheet": return "data" as an object with "headers" (array of strings) and "rows" (array of arrays, at least 10 rows with realistic sample data).
- "business_plan": return "sections" as an array of objects with "heading" (string) and "text" (string, 3-5 sentences each). At least 8 sections.
- "canva": return "content" as a plain string describing the design layout and suggested copy for each section.

Return ONLY a valid JSON object. No extra text. No markdown fences.
The JSON must have a "type" field matching the template type, plus the relevant data field above.
"""
    response = client.chat.completions.create(
        model="deepseek-chat",
        messages=[{"role": "user", "content": prompt}],
        temperature=0.7,
        max_tokens=4000,
    )
    raw = response.choices[0].message.content
    try:
        return _extract_json(raw)
    except Exception:
        return {"type": template_type, "content": raw}


def generate_product_description(idea: dict) -> str:
    """Generate a rich marketing description for the product page."""
    prompt = f"""
Write a compelling 3-paragraph marketing description for this digital template product:
Title: {idea['title']}
Target audience: {idea['audience']}
Features: {', '.join(idea.get('features', []))}

Make it persuasive, professional, and highlight time-saving benefits.
Return plain text only.
"""
    response = client.chat.completions.create(
        model="deepseek-chat",
        messages=[{"role": "user", "content": prompt}],
        temperature=0.7,
        max_tokens=600,
    )
    return response.choices[0].message.content.strip()
