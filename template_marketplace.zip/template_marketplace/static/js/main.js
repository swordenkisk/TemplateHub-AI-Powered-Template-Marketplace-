// ─────────────────────────────────────────────
// TemplateHub — main.js
// ─────────────────────────────────────────────

// Update cart badge via API
async function updateCartBadge() {
  try {
    const res  = await fetch('/api/cart/count');
    const data = await res.json();
    const badge = document.getElementById('cart-badge');
    if (badge) badge.textContent = data.count;
  } catch (e) {
    // fail silently
  }
}

// Flash message auto-dismiss
document.querySelectorAll('.alert').forEach(el => {
  setTimeout(() => {
    el.style.transition = 'opacity 0.5s';
    el.style.opacity    = '0';
    setTimeout(() => el.remove(), 500);
  }, 5000);
});

// Add-to-cart quick feedback
document.querySelectorAll('a[href^="/add_to_cart"]').forEach(link => {
  link.addEventListener('click', function(e) {
    const original = this.textContent;
    this.textContent = '✅ Added!';
    setTimeout(() => this.textContent = original, 1500);
    // Update badge after navigation resolves
    setTimeout(updateCartBadge, 400);
  });
});

document.addEventListener('DOMContentLoaded', updateCartBadge);
