import os
import json
import uuid
import stripe
from datetime import datetime
from functools import wraps
from flask import (Flask, render_template, request, redirect,
                   url_for, session, jsonify, send_file, abort)
from dotenv import load_dotenv

load_dotenv()

from generator.ai_generator import (
    generate_template_ideas,
    generate_template_content,
    generate_product_description,
)
from generator.file_creator import TemplateCreator

app = Flask(__name__)
app.secret_key = os.getenv("FLASK_SECRET_KEY", os.urandom(32))
stripe.api_key = os.getenv("STRIPE_SECRET_KEY", "")

PRODUCTS_FILE = "products.json"
ORDERS_FILE   = "orders.json"


# ─────────────────────────────────────────────────────────────────────────────
# Data helpers
# ─────────────────────────────────────────────────────────────────────────────

def load_products() -> list:
    if os.path.exists(PRODUCTS_FILE):
        with open(PRODUCTS_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    return []


def save_products(products: list):
    with open(PRODUCTS_FILE, "w", encoding="utf-8") as f:
        json.dump(products, f, indent=2, ensure_ascii=False)


def load_orders() -> list:
    if os.path.exists(ORDERS_FILE):
        with open(ORDERS_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    return []


def save_order(order: dict):
    orders = load_orders()
    orders.append(order)
    with open(ORDERS_FILE, "w", encoding="utf-8") as f:
        json.dump(orders, f, indent=2, ensure_ascii=False)


def get_product(product_id: int):
    return next((p for p in load_products() if p["id"] == product_id), None)


# ─────────────────────────────────────────────────────────────────────────────
# Admin auth decorator
# ─────────────────────────────────────────────────────────────────────────────

def admin_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        if not session.get("admin_logged_in"):
            return redirect(url_for("admin_login"))
        return f(*args, **kwargs)
    return decorated


# ─────────────────────────────────────────────────────────────────────────────
# Store routes
# ─────────────────────────────────────────────────────────────────────────────

@app.route("/")
def index():
    products = load_products()
    type_filter = request.args.get("type", "all")
    search      = request.args.get("search", "").lower()

    if type_filter != "all":
        products = [p for p in products if p["type"] == type_filter]
    if search:
        products = [p for p in products
                    if search in p["title"].lower() or search in p["description"].lower()]

    types = ["all", "presentation", "spreadsheet", "business_plan", "canva"]
    return render_template("index.html", products=products,
                           types=types, active_type=type_filter, search=search)


@app.route("/product/<int:product_id>")
def product(product_id):
    p = get_product(product_id)
    if not p:
        abort(404)
    return render_template("product.html", product=p)


@app.route("/add_to_cart/<int:product_id>")
def add_to_cart(product_id):
    cart = session.get("cart", [])
    if product_id not in cart:
        cart.append(product_id)
    session["cart"] = cart
    return redirect(request.referrer or url_for("index"))


@app.route("/remove_from_cart/<int:product_id>")
def remove_from_cart(product_id):
    cart = session.get("cart", [])
    cart = [x for x in cart if x != product_id]
    session["cart"] = cart
    return redirect(url_for("cart"))


@app.route("/cart")
def cart():
    cart_ids   = session.get("cart", [])
    products   = load_products()
    cart_items = [p for p in products if p["id"] in cart_ids]
    total      = round(sum(p["price"] for p in cart_items), 2)
    stripe_pub = os.getenv("STRIPE_PUBLIC_KEY", "")
    return render_template("cart.html", items=cart_items,
                           total=total, stripe_public_key=stripe_pub)


@app.route("/checkout", methods=["POST"])
def checkout():
    cart_ids = session.get("cart", [])
    if not cart_ids:
        return redirect(url_for("index"))

    products   = load_products()
    cart_items = [p for p in products if p["id"] in cart_ids]

    if not stripe.api_key or stripe.api_key.startswith("sk_test_your"):
        # Demo mode — skip real Stripe
        demo_items = cart_items
        order = {
            "id": str(uuid.uuid4()),
            "items": demo_items,
            "total": round(sum(p["price"] for p in demo_items), 2),
            "customer_email": "demo@example.com",
            "date": datetime.now().isoformat(),
            "status": "demo_paid",
        }
        save_order(order)
        session.pop("cart", None)
        session["last_order"] = order["id"]
        return redirect(url_for("success") + "?demo=1")

    try:
        checkout_session = stripe.checkout.Session.create(
            payment_method_types=["card"],
            line_items=[
                {
                    "price_data": {
                        "currency": "usd",
                        "product_data": {"name": item["title"]},
                        "unit_amount": int(item["price"] * 100),
                    },
                    "quantity": 1,
                }
                for item in cart_items
            ],
            mode="payment",
            customer_email=None,
            success_url=url_for("success", _external=True)
            + "?session_id={CHECKOUT_SESSION_ID}",
            cancel_url=url_for("cart", _external=True),
            metadata={"cart_ids": json.dumps(cart_ids)},
        )
        return redirect(checkout_session.url, code=303)
    except stripe.error.StripeError as e:
        return render_template("error.html", message=str(e)), 500


@app.route("/success")
def success():
    demo = request.args.get("demo")
    if demo:
        orders = load_orders()
        order  = orders[-1] if orders else {}
        return render_template("success.html", items=order.get("items", []), order=order)

    session_id = request.args.get("session_id")
    if not session_id:
        return redirect(url_for("index"))

    try:
        cs = stripe.checkout.Session.retrieve(session_id)
    except stripe.error.StripeError:
        return redirect(url_for("index"))

    if cs.payment_status == "paid":
        cart_ids   = json.loads(cs.metadata.get("cart_ids", "[]"))
        products   = load_products()
        cart_items = [p for p in products if p["id"] in cart_ids]
        order = {
            "id": session_id,
            "items": cart_items,
            "total": cs.amount_total / 100,
            "customer_email": (cs.customer_details.email
                               if cs.customer_details else ""),
            "date": datetime.now().isoformat(),
            "status": "paid",
        }
        save_order(order)
        session.pop("cart", None)
        return render_template("success.html", items=cart_items, order=order)

    return redirect(url_for("cart"))


@app.route("/download/<int:product_id>")
def download(product_id):
    """Allow download of a purchased template (basic: honour-system check)."""
    p = get_product(product_id)
    if not p:
        abort(404)
    filepath = p.get("file", "")
    if not filepath or not os.path.exists(filepath):
        abort(404)
    return send_file(filepath, as_attachment=True)


# ─────────────────────────────────────────────────────────────────────────────
# Admin routes
# ─────────────────────────────────────────────────────────────────────────────

@app.route("/admin/login", methods=["GET", "POST"])
def admin_login():
    error = None
    if request.method == "POST":
        password = request.form.get("password", "")
        if password == os.getenv("ADMIN_PASSWORD", "admin123"):
            session["admin_logged_in"] = True
            return redirect(url_for("admin_dashboard"))
        error = "Invalid password."
    return render_template("admin_login.html", error=error)


@app.route("/admin/logout")
def admin_logout():
    session.pop("admin_logged_in", None)
    return redirect(url_for("index"))


@app.route("/admin")
@admin_required
def admin_dashboard():
    products = load_products()
    orders   = load_orders()
    revenue  = sum(o.get("total", 0) for o in orders if o.get("status") in ("paid", "demo_paid"))
    return render_template("admin_dashboard.html", products=products,
                           orders=orders, revenue=revenue)


@app.route("/admin/generate", methods=["GET", "POST"])
@admin_required
def admin_generate():
    message = None
    if request.method == "POST":
        template_type = request.form["type"]
        count         = max(1, min(int(request.form.get("count", 3)), 10))
        price         = float(request.form.get("price", 9.99))

        ideas   = generate_template_ideas(template_type, count)
        creator = TemplateCreator()
        products = load_products()
        added    = 0

        for idea in ideas:
            try:
                content_data = generate_template_content(template_type, idea)
            except Exception:
                content_data = {}

            safe_name = "".join(c if c.isalnum() else "_" for c in idea["title"])[:40]
            new_id    = max((p["id"] for p in products), default=0) + 1

            try:
                if template_type == "presentation":
                    filename = f"{safe_name}.pptx"
                    filepath = creator.create_pptx(
                        idea["title"],
                        content_data.get("slides", []),
                        filename,
                    )
                elif template_type == "spreadsheet":
                    filename = f"{safe_name}.xlsx"
                    filepath = creator.create_xlsx(
                        idea["title"],
                        content_data.get("data", {}),
                        filename,
                    )
                elif template_type == "business_plan":
                    filename = f"{safe_name}.docx"
                    filepath = creator.create_docx(
                        idea["title"],
                        content_data.get("sections", []),
                        filename,
                    )
                elif template_type == "canva":
                    filename = f"{safe_name}.pdf"
                    filepath = creator.create_pdf(
                        idea["title"],
                        content_data.get("content", ""),
                        filename,
                    )
                else:
                    continue
            except Exception as e:
                app.logger.error(f"File creation failed for {idea['title']}: {e}")
                continue

            thumbnail = creator.create_thumbnail(idea["title"], template_type, new_id)

            product = {
                "id":          new_id,
                "title":       idea["title"],
                "description": idea["description"],
                "long_desc":   generate_product_description(idea),
                "price":       float(idea.get("price_suggestion", price)),
                "type":        template_type,
                "file":        filepath,
                "thumbnail":   thumbnail,
                "audience":    idea.get("audience", "General"),
                "features":    idea.get("features", []),
                "created_at":  datetime.now().isoformat(),
            }
            products.append(product)
            added += 1

        save_products(products)
        message = f"✅ Successfully generated {added} new template(s)."

    return render_template("admin_generate.html", message=message)


@app.route("/admin/delete/<int:product_id>", methods=["POST"])
@admin_required
def admin_delete(product_id):
    products = [p for p in load_products() if p["id"] != product_id]
    save_products(products)
    return redirect(url_for("admin_dashboard"))


@app.route("/admin/orders")
@admin_required
def admin_orders():
    orders = load_orders()
    return render_template("admin_orders.html", orders=orders)


# ─────────────────────────────────────────────────────────────────────────────
# API endpoints (JSON)
# ─────────────────────────────────────────────────────────────────────────────

@app.route("/api/products")
def api_products():
    return jsonify(load_products())


@app.route("/api/cart/count")
def api_cart_count():
    return jsonify({"count": len(session.get("cart", []))})


# ─────────────────────────────────────────────────────────────────────────────
# Error handlers
# ─────────────────────────────────────────────────────────────────────────────

@app.errorhandler(404)
def not_found(e):
    return render_template("error.html", message="Page not found."), 404


@app.errorhandler(500)
def server_error(e):
    return render_template("error.html", message="Internal server error."), 500


if __name__ == "__main__":
    app.run(debug=True, host="0.0.0.0", port=5000)
